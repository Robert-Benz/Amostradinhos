import { 
    initializeApp 
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

import { 
    getFirestore, 
    collection, 
    addDoc, 
    getDocs, 
    query, 
    where,
    doc,
    deleteDoc,
    updateDoc
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

 
const firebaseConfig = {
    apiKey: "AIzaSyDuRanJfUv_9kH3qU-plmea3NPJVLseXCA",
    authDomain: "mindquest-d8722.firebaseapp.com",
    databaseURL: "https://mindquest-d8722-default-rtdb.firebaseio.com",
    projectId: "mindquest-d8722",
    storageBucket: "mindquest-d8722.firebasestorage.app",
    messagingSenderId: "850445528346",
    appId: "1:850445528346:web:cc4d1e461ba01f27c050a3",
    measurementId: "G-4RFLW0MTNT"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

console.log("MindQuest: App carregado!");

 
const btnCriar = document.getElementById("btnCriarConta");

if (btnCriar) {
    btnCriar.addEventListener("click", async () => {
        const nome = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const senha = document.getElementById("pw").value;
        const tipo = document.getElementById("role").value;

        if (!nome || !email || !senha) {
            alert("Preencha todos os campos!");
            return;
        }

        try {
            const docRef = await addDoc(collection(db, "usuarios"), {
                nome: nome,
                email: email.toLowerCase(),
                senha: senha,
                role: tipo,
                dataCriacao: new Date()
            });

            alert("Conta criada! ID: " + docRef.id);
            
            const usuarioSessao = { id: docRef.id, nome: nome, email: email, role: tipo };
            localStorage.setItem("mindquest_current", JSON.stringify(usuarioSessao));
 
            if (tipo === "patient") {
                window.location.href = "formulario.html"; 
            } else {
                window.location.href = "psicologo-dashboard.html";
            }

        } catch (erro) {
            console.error(erro);
            alert("Erro ao criar conta: " + erro.message);
        }
    });
}
 
const btnLogin = document.getElementById("btnLogin");

if (btnLogin) {
    btnLogin.addEventListener("click", async () => {
        const email = document.getElementById("loginEmail").value;
        const senha = document.getElementById("loginSenha").value;

        if (!email || !senha) {
            alert("Preencha e-mail e senha!");
            return;
        }

        try {
            const q = query(collection(db, "usuarios"), where("email", "==", email.toLowerCase()));
            const querySnapshot = await getDocs(q);

            if (querySnapshot.empty) {
                alert("E-mail não encontrado!");
                return;
            }

            const docUsuario = querySnapshot.docs[0];
            const dados = docUsuario.data();

            if (dados.senha !== senha) {
                alert("Senha incorreta!");
                return;
            }

            const usuarioSessao = { 
                id: docUsuario.id, 
                nome: dados.nome, 
                email: dados.email, 
                role: dados.role || dados.tipo 
            };
            
            localStorage.setItem("mindquest_current", JSON.stringify(usuarioSessao));
            
        
            if (usuarioSessao.role === "patient") {
                window.location.href = "patientDashboard.html"; 
            } else {
                window.location.href = "psicologo-dashboard.html";
            }

        } catch (erro) {
            console.error("Erro no Login:", erro);
            alert("Erro técnico: " + erro.message);
        }
    });
}

 
const listaPacientes = document.getElementById("lista-pacientes");
if (listaPacientes) {
    async function carregarPacientes() {
        listaPacientes.innerHTML = "<p>Carregando...</p>";
        try {
            const snapshot = await getDocs(collection(db, "usuarios"));
            listaPacientes.innerHTML = "";
            snapshot.forEach(doc => {
                const d = doc.data();
                if (d.role === "patient" || d.tipo === "patient") {
                    const div = document.createElement("div");
                    div.style.border = "1px solid #ccc";
                    div.style.padding = "10px";
                    div.style.marginBottom = "10px";
                    div.innerHTML = `<b>${d.nome}</b><br>${d.email}`;
                    listaPacientes.appendChild(div);
                }
            });
        } catch (e) { console.error(e); }
    }
    carregarPacientes();
}

 
const btnSair = document.getElementById("btnSair");
if (btnSair) {
    btnSair.addEventListener("click", () => {
        localStorage.removeItem("mindquest_current");
        window.location.href = "index.html";
    });
}

 
const btnSalvarHumor = document.getElementById("btnSalvarHumor");
if (btnSalvarHumor) {
    btnSalvarHumor.addEventListener("click", async () => {
        const usuarioLogado = JSON.parse(localStorage.getItem("mindquest_current"));
        if (!usuarioLogado) { alert("Erro: Não logado!"); return; }

        const sentimento = document.getElementById("humorSelect").value;
        const nivel = document.getElementById("humorNivel").value;
        const notas = document.getElementById("humorNotas").value;

        try {
            await addDoc(collection(db, "registros_humor"), {
                uid_usuario: usuarioLogado.id,
                email_usuario: usuarioLogado.email,
                sentimento: sentimento,
                nivel: nivel,
                notas: notas,
                data: new Date()
            });
            alert("Humor registrado!");
            window.location.href = "patientDashboard.html";
        } catch (erro) { alert("Erro ao salvar."); }
    });
}

 
const listaHistorico = document.getElementById("listaHistorico");
const modalOverlay = document.getElementById("modalConfirm");
const btnModalConfirmar = document.getElementById("btnModalConfirmar");
const btnModalCancelar = document.getElementById("btnModalCancelar");
const modalTitulo = document.getElementById("modalTitulo");
const modalMsg = document.getElementById("modalMsg");

let acaoAtual = null; 
let idAlvo = null;    
let textoParaSalvar = null;
let funcaoConfirmacao = null;

if (listaHistorico) {
  
    if(btnModalCancelar) {
        btnModalCancelar.addEventListener("click", () => {
            modalOverlay.style.display = "none";
            funcaoConfirmacao = null;
        });
    }
    if(btnModalConfirmar) {
        btnModalConfirmar.addEventListener("click", () => {
            if (funcaoConfirmacao) funcaoConfirmacao();
            modalOverlay.style.display = "none";
        });
    }

    function prepararModal(tipo, idDoc, novoTexto = "") {
        modalOverlay.style.display = "flex";
        idAlvo = idDoc;
        acaoAtual = tipo;
        
        if (tipo === 'excluir') {
            modalTitulo.innerText = "Excluir Registro";
            modalMsg.innerText = "Tem certeza que deseja apagar?";
            btnModalConfirmar.className = "btn-modal btn-vermelho"; 
            
            funcaoConfirmacao = async () => {
                try {
                    await deleteDoc(doc(db, "registros_humor", idDoc));
                    carregarHistorico();
                } catch (e) { alert("Erro: " + e.message); }
            };

        } else if (tipo === 'editar') {
            modalTitulo.innerText = "Salvar Alteração";
            modalMsg.innerText = "Confirmar novo texto e atualizar data?";
            btnModalConfirmar.className = "btn-modal btn-roxo"; 
            
            funcaoConfirmacao = async () => {
                try {
                    await updateDoc(doc(db, "registros_humor", idDoc), {
                        notas: novoTexto,
                        data: new Date()  
                    });
                    carregarHistorico();
                } catch (e) { alert("Erro: " + e.message); }
            };
        }
    }

    async function carregarHistorico() {
        const usuarioLogado = JSON.parse(localStorage.getItem("mindquest_current"));
        if (!usuarioLogado) { listaHistorico.innerHTML = "<p>Não logado.</p>"; return; }

        try {
            const q = query(collection(db, "registros_humor"), where("uid_usuario", "==", usuarioLogado.id));
            const querySnapshot = await getDocs(q);

            if (querySnapshot.empty) {
                listaHistorico.innerHTML = "<p style='text-align:center'>Nenhum registro ainda.</p>";
                return;
            }

            listaHistorico.innerHTML = ""; 
            let docs = [];
            querySnapshot.forEach(doc => docs.push({id: doc.id, data: doc.data()}));
          
            docs.sort((a, b) => b.data.data.seconds - a.data.data.seconds);

            docs.forEach((item) => {
                const dados = item.data;
                const idDoc = item.id;
                
                let dataFormatada = "--/--";
                if (dados.data && dados.data.seconds) {
                    const dataObj = new Date(dados.data.seconds * 1000);
                    dataFormatada = dataObj.toLocaleDateString('pt-BR', {day:'2-digit', month:'2-digit'}) + " " + dataObj.toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
                }

                let emoji = "😐";
                if(dados.sentimento === 'feliz') emoji = "😄";
                if(dados.sentimento === 'triste') emoji = "😢";
                if(dados.sentimento === 'ansioso') emoji = "😰";
                if(dados.sentimento === 'irritado') emoji = "😠";

                const divCard = document.createElement("div");
                divCard.className = "mood-item";
                divCard.innerHTML = `
                    <div class="mood-header">
                        <span>${emoji} ${dados.sentimento.toUpperCase()}</span>
                        <span class="arrow">▼</span>
                    </div>
                    <div class="mood-details">
                        <p><strong>📅 Data:</strong> ${dataFormatada}</p>
                        <p><strong>📊 Nível:</strong> ${dados.nivel}/10</p>
                        <div id="container-texto-${idDoc}">
                            <p><strong>📝 Notas:</strong><br><span id="texto-${idDoc}">${dados.notas || "<em>Sem anotações.</em>"}</span></p>
                        </div>
                        <div id="actions-${idDoc}" class="mood-actions">
                            <button class="btn-small btn-edit" id="btn-edit-${idDoc}">Editar</button>
                            <button class="btn-small btn-delete" id="btn-del-${idDoc}">Excluir</button>
                        </div>
                    </div>
                `;

                divCard.addEventListener("click", (e) => {
                    if(!['BUTTON','TEXTAREA','INPUT'].includes(e.target.tagName)) divCard.classList.toggle("ativo");
                });

                divCard.querySelector(`#btn-del-${idDoc}`).addEventListener("click", (e) => {
                    e.stopPropagation();
                    prepararModal('excluir', idDoc);
                });

                divCard.querySelector(`#btn-edit-${idDoc}`).addEventListener("click", (e) => {
                    e.stopPropagation();
                    const container = divCard.querySelector(`#container-texto-${idDoc}`);
                    if (container.querySelector('textarea')) return;
                    
                    divCard.querySelector(`#actions-${idDoc}`).style.display = "none";
                    const txtAtual = dados.notas || "";
                    
                    container.innerHTML = `
                        <p><strong>📝 Editando:</strong></p>
                        <textarea id="input-${idDoc}" class="edit-area" rows="3">${txtAtual}</textarea>
                        <div style="text-align:right; margin-top:5px;">
                            <button class="btn-small btn-cinza" id="btn-cancel-${idDoc}">Cancelar</button>
                            <button class="btn-small" style="background:#27ae60" id="btn-save-${idDoc}">Salvar</button>
                        </div>
                    `;

                    divCard.querySelector(`#btn-save-${idDoc}`).addEventListener("click", (ev) => {
                        ev.stopPropagation();
                        prepararModal('editar', idDoc, divCard.querySelector(`#input-${idDoc}`).value);
                    });
                    
                    divCard.querySelector(`#btn-cancel-${idDoc}`).addEventListener("click", (ev) => {
                        ev.stopPropagation();
                        carregarHistorico();
                    });
                });

                listaHistorico.appendChild(divCard);
            });
        } catch (erro) { console.error(erro); }
    }
    carregarHistorico();
}
 
const recsContainer = document.getElementById("recs");

if (recsContainer) {
    const prefs = JSON.parse(localStorage.getItem("mindquest_prefs") || "{}");
    let recs = [];

     
    if(prefs.musica?.includes("lo-fi") || prefs.musica?.includes("indie")) recs.push("Journaling com música lo-fi");
    if(prefs.musica?.includes("pop")) recs.push("Dancinha terapêutica por 5 minutos");
    if(prefs.musica?.includes("rock")) recs.push("Respiração 4-4-4 com rock leve");
    
    if(prefs.clima === "Chuvoso") recs.push("Leitura com som de chuva");
    if(prefs.clima === "Ensolarado") recs.push("Caminhada curta ao ar livre");
    
    if(prefs.energia === "Baixo") recs.push("Alongamento suave");
    if(prefs.energia === "Alto") recs.push("Cardio leve de 5 min");
    
    if(prefs.personalidade === "Introvertida") recs.push("Meditação de 10 minutos");
    if(prefs.personalidade === "Extrovertida") recs.push("Ligar para um amigo");
    
    if(prefs.tempo === "Menos de 10 min") recs.push("Respiração quadrada");
    if(prefs.tempo === "Mais de 1 hora") recs.push("Projeto criativo / Pintura");
    
    if(prefs.ambiente === "Casa") recs.push("Organizar o quarto por 5 min");
    if(prefs.ambiente === "Ao ar livre") recs.push("Caminhada consciente");
    
    if(recs.length === 0) recs.push("Pratique 5 minutos de respiração consciente.");
    
    recsContainer.innerHTML = "";
    
     
    recs.forEach(r => {
        const div = document.createElement("div");
        div.className = "rec-item"; 
        div.innerHTML = r;
        recsContainer.appendChild(div);
    });
}